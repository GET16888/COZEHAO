## 归档更新日志

2023.04.26： 支持企业微信应用号部署，兼容插件，并支持语音图片交互，私人助理理想选择，使用文档。(contributed by @lanvent in #944)

2023.04.05： 支持微信公众号部署，兼容插件，并支持语音图片交互，使用文档。(contributed by @JS00000 in #686)

2023.04.05： 增加能让ChatGPT使用工具的tool插件，使用文档。工具相关issue可反馈至chatgpt-tool-hub。(contributed by @goldfishh in #663)

2023.03.25： 支持插件化开发，目前已实现 多角色切换、文字冒险游戏、管理员指令、Stable Diffusion等插件，使用参考 #578。(contributed by @lanvent in #565)

2023.03.09： 基于 whisper API(后续已接入更多的语音API服务) 实现对语音消息的解析和回复，添加配置项 "speech_recognition":true 即可启用，使用参考 #415。(contributed by wanggang1987 in #385)

2023.02.09： 扫码登录存在账号限制风险，请谨慎使用，参考#58